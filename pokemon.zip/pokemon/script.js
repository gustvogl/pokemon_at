// --- Elementos da DOM ---
const cards = document.querySelectorAll('.game-card');
const clockElement = document.getElementById('clock');
const menuItems = document.querySelectorAll('.system-menu-row .sys-icon');
const menuFooterText = document.querySelector('.current-menu-item');

// --- Controles Físicos (Mantidos) ---
const btnA = document.querySelector('.abxy-pad .btn.a');
const btnLeft = document.querySelector('.d-pad .arrow.left');
const btnRight = document.querySelector('.d-pad .arrow.right');
// ... (outros botões)

// --- Estado do Sistema ---
let currentIndex = 0; // Index do card de atividade (Se > -1, a linha de jogos está ativa)
let currentMenuItemIndex = 0; // Index do ícone do menu inferior (Se > -1, a linha de menu está ativa)

// Textos para o rodapé (AJUSTADO PARA PORTUGUÊS)
const menuTexts = ["Notícias de Jogos", "eShop", "Álbum", "Controles", "Configurações", "Desligar"]; 

// --- Funções de UI ---

/**
 * Atualiza a seleção visual na linha de Atividades/Jogos.
 * Desativa a seleção se o index for -1.
 */
function updateGameCardSelection(index) {
    cards.forEach(card => card.classList.remove('active'));
    if (index > -1) {
        cards[index].classList.add('active');
        cards[index].scrollIntoView({
            behavior: 'smooth',
            inline: 'center',
            block: 'nearest'
        });
    }
}

/**
 * Atualiza a seleção visual na linha de Ícones do Sistema.
 * Atualiza o texto do rodapé.
 */
function updateMenuItemSelection(index) {
    menuItems.forEach(item => item.classList.remove('active'));
    if (index > -1 && index < menuItems.length) {
        menuItems[index].classList.add('active');
        menuFooterText.innerText = menuTexts[index];
    } else {
         // Se nenhum item do menu estiver ativo, o footer pode mostrar o status
        menuFooterText.innerText = 'Home'; 
    }
}

function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    if (clockElement) {
        clockElement.innerText = `${hours}:${minutes}`;
    }
}

// --- Funções de Ação (simulação) ---

function initiateActivity(cardIndex) {
    const activityName = cards[cardIndex].getAttribute('data-name');
    alert(`Iniciando ${activityName}...`);
}

function openMenuItem(itemIndex) {
    alert(`Abrindo: ${menuTexts[itemIndex]}`);
}

// --- Event Listeners ---

// Inicialização
window.onload = () => {
    updateClock();
    setInterval(updateClock, 1000); // Atualiza o relógio a cada segundo
    updateGameCardSelection(currentIndex); // Seleciona o primeiro jogo
    updateMenuItemSelection(-1); // Inicialmente, o menu inferior não está ativo
    
    // Configura o texto do botão A/Enter no rodapé
    document.querySelector('.controls-help span').innerText = 'A Iniciar';
};

// --- NAVEGAÇÃO HORIZONTAL (Geral) ---

function navigateHorizontal(direction) {
    // 1. Linha de JOGOS está ativa
    if (currentIndex > -1) {
        if (direction === 'right' && currentIndex < cards.length - 1) {
            currentIndex++;
        } else if (direction === 'left' && currentIndex > 0) {
            currentIndex--;
        }
        updateGameCardSelection(currentIndex);
    } 
    // 2. Linha de ÍCONES está ativa
    else if (currentMenuItemIndex > -1) {
        if (direction === 'right' && currentMenuItemIndex < menuItems.length - 1) {
            currentMenuItemIndex++;
        } else if (direction === 'left' && currentMenuItemIndex > 0) {
            currentMenuItemIndex--;
        }
        updateMenuItemSelection(currentMenuItemIndex);
    }
}

btnLeft.addEventListener('click', () => navigateHorizontal('left'));
btnRight.addEventListener('click', () => navigateHorizontal('right'));

// Clique direto no card (mouse)
cards.forEach((card, index) => {
    card.addEventListener('click', () => {
        currentIndex = index;
        currentMenuItemIndex = -1; // Desativa o menu inferior
        updateGameCardSelection(currentIndex);
        updateMenuItemSelection(currentMenuItemIndex);
    });
});

// --- AÇÃO DE INICIAR (Botão A / Enter) ---
function handleAction() {
    // Efeito visual (apenas para o clique do mouse no botão A, o keydown não aciona isso)
    btnA.style.transform = "translateY(2px)";
    setTimeout(() => btnA.style.transform = "translateY(0)", 100);

    if (currentIndex > -1) {
        initiateActivity(currentIndex);
    } else if (currentMenuItemIndex > -1) {
        openMenuItem(currentMenuItemIndex);
    }
}

btnA.addEventListener('click', handleAction);

// --- NAVEGAÇÃO COMPLETA (Teclado) ---
document.addEventListener('keydown', (e) => {
    
    // NAVEGAÇÃO HORIZONTAL
    if (e.key === 'ArrowLeft') {
        navigateHorizontal('left');
    } else if (e.key === 'ArrowRight') {
        navigateHorizontal('right');
    } 
    // AÇÃO
    else if (e.key === 'Enter') {
        handleAction();
    } 
    // NAVEGAÇÃO VERTICAL
    else if (e.key === 'ArrowDown') {
        if (currentIndex > -1) {
            // Mover para a linha de Ícones
            currentIndex = -1; 
            currentMenuItemIndex = 0; // Seleciona o primeiro ícone
            updateGameCardSelection(currentIndex);
            updateMenuItemSelection(currentMenuItemIndex);
        }
    } else if (e.key === 'ArrowUp') { 
        if (currentMenuItemIndex > -1) {
            // Mover para a linha de Jogos
            currentMenuItemIndex = -1; 
            currentIndex = 0; // Volta para o primeiro jogo
            updateMenuItemSelection(currentMenuItemIndex);
            updateGameCardSelection(currentIndex);
        }
    }
});

// --- Botões Físicos do Joy-Con (feedback visual) ---
// (Este bloco permanece o mesmo, garantindo o feedback visual em mousedown/mouseup)
[/* ... Lista de botões ... */]
.forEach(button => {
    // ... (lógica de mousedown/mouseup) ...
});